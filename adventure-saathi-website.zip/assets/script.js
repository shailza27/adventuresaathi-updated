// Mobile nav toggle
var menuToggle = document.querySelector('.menu-toggle');
if (menuToggle) {
  menuToggle.addEventListener('click', function () {
    var nav = document.querySelector('.primary-nav');
    var isOpen = nav.style.display === 'flex';
    nav.style.cssText = isOpen ? '' : 'display:flex; flex-direction:column; position:fixed; top:64px; left:0; right:0; background:#EEF1EA; padding:24px 32px; gap:20px; border-bottom:1px solid rgba(22,36,31,0.12); z-index:99;';
  });
}

// Contact form -> WhatsApp
var contactForm = document.querySelector('.contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', function (e) {
    e.preventDefault();

    var whatsappNumber = '918808970991'; // Adventure Saathi WhatsApp — country code + number, no + or spaces

    var name = document.getElementById('name').value.trim();
    var phone = document.getElementById('phone').value.trim();
    var email = document.getElementById('email').value.trim();
    var trip = document.getElementById('trip').value;
    var message = document.getElementById('message').value.trim();

    var lines = [
      'Hi Adventure Saathi, I\'d like to enquire about a trip.',
      '',
      'Name: ' + name,
      'Phone: ' + phone,
      'Email: ' + email,
      'Interested in: ' + trip
    ];
    if (message) {
      lines.push('Notes: ' + message);
    }

    var waText = encodeURIComponent(lines.join('\n'));
    var waUrl = 'https://wa.me/' + whatsappNumber + '?text=' + waText;

    var btn = this.querySelector('.submit-btn');
    btn.textContent = 'Opening WhatsApp…';
    btn.style.background = '#1F3D30';

    window.open(waUrl, '_blank');

    setTimeout(function () {
      btn.textContent = 'Send via WhatsApp';
      btn.style.background = '';
    }, 2500);
  });
}

// FAQ accordion (trek detail pages)
document.querySelectorAll('.faq-question').forEach(function (btn) {
  btn.addEventListener('click', function () {
    var item = btn.closest('.faq-item');
    var wasOpen = item.classList.contains('open');
    document.querySelectorAll('.faq-item.open').forEach(function (openItem) {
      openItem.classList.remove('open');
    });
    if (!wasOpen) {
      item.classList.add('open');
    }
  });
});
